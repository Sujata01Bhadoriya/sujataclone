// strings
// sequnce of characters

let str = 'Hello World Hello'
let str2= "Goodbye World"

// replace
let text1 = str.replace("Hello" , 'Namaste')
console.log(str)

console.log(text1) // Namaste World

// toLowerCase

let text3= 'SCALER' // scaler
let text4 = 'abcd' // ABCD 

let lowerCaseText = text3.toLowerCase()
console.log(lowerCaseText)

let upperCaseText= text4.toUpperCase().toLowerCase()
console.log(upperCaseText)

// concat

let greeting = 'Hello'
let personName = 'Suraj'

let concatenatedString= "Hello" + " "+ "Suraj";
console.log(concatenatedString)

let str5 = 'Hello' // "olleH"

let result = str5.split('')
console.log(result)

let reveresArr = result.reverse()
console.log(reveresArr)

let reversedStr = reveresArr.join('')
console.log(reversedStr)











