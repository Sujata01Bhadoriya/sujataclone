let cars = ['Bentley' , 'Volvo' , 'Urus']

//  console.log(cars)
// length property
// console.log(cars.length)

// Array Methods

// push method - it adds an element at the end of an array

// cars.push('Ferrari')
// console.log(cars)

// // pop method - remove an element from the end of an Array

// cars.pop() // ferrari
// cars.pop() // urus
// console.log(cars)

// shift and unshift

// unshift - It adds an element at the starting

// cars.unshift('BMW')

// console.log(cars)

// shift method

// cars.shift()// BMW
// cars.shift()// Bentley

// console.log(cars)

// includes- This will return boolean value based on if the element exists or not

// let hasCar = cars.includes('mercedes')
// console.log(hasCar)

// indexOf

// let index = cars.indexOf('Urus')
// console.log(index)

// Slice and splice



// let slicedCars = cars2.slice(2,4)

// console.log(slicedCars)

let cars2 = ['Bentley' , 'Volvo' , 'Urus' , 'BMW' , 'Mercedes' , 'rolls royce']
// splice

let splicedArr = cars2.splice(2,4)
console.log(splicedArr)















