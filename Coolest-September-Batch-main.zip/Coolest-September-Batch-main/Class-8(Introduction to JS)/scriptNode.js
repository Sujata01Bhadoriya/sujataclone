//  How to comment in JS
//  Variables in JS

let a = 20
console.log(a) // Number


a = 'Hello'
console.log(typeof a)

const c = 3.14



console.log(typeof c) // number




// var b = "S" // String
// console.log(typeof b)

// var c = false // boolean
// console.log(typeof c)




