// function greet(){
//     console.log('Hello')
// }

// greet() // fucnction invokation , function call

// // Function to server beverages

// function serveDrink(drink){
//   console.log(drink + ' served')
// }

// serveDrink('tea')
// serveDrink('coffee')


// Add two Numbers

function addNums(a ,b){
   if( typeof a=='number' && typeof b=='number'){
    return a+b
   }
   else{
    console.log('numbers are not recieved')
   }
}

let sum = addNums('hello',3)
console.log(sum)

// function mul2(val){
//   return val*2
// }

// let product = mul2(sum)
// console.log(product)

